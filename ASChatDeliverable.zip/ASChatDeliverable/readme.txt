MMMMMMMMMMMM MMMMMMMMMMMM MMMMMMMMMMMM MMMMMMMMMMM MMMMMMMMMMMM MMMMMMMMMMMM 
MMP"""""""MM MP""""""`MM MM'""""'YMM M""MMMMM""MM MMP"""""""MM M""""""""M`MM
M' .mmmm  MM M  mmmmm..M M' .mmm. `M M  MMMMM  MM M' .mmmm  MM Mmmm  mmmM`MM
M         `M M.      `YM M  MMMMMooM M         `M M         `M MMMM  MMMM`MM
M  MMMMM  MM MMMMMMM.  M M  MMMMMMMM M  MMMMM  MM M  MMMMM  MM MMMM  MMMM`MM
M  MMMMM  MM M. .MMM'  M M. `MMM' .M M  MMMMM  MM M  MMMMM  MM MMMM  MMMM`MM
M  MMMMM  MM Mb.     .dM MM.     .dM M  MMMMM  MM M  MMMMM  MM MMMM  MMMM`MM
MMMMMMMMMMMM MMMMMMMMMMM MMMMMMMMMMM MMMMMMMMMMMM MMMMMMMMMMMM MMMMMMMMMM`MM
MM"""""""`MM MM""""""""`M MMP"""""""MM M""""""'YMM MM""""""""`M MM"""""""`MM 
MM  mmmm,  M MM  mmmmmmmM M' .mmmm  MM M  mmmm. `M MM  mmmmmmmM MM  mmmm,  M 
M'        .M M`      MMMM M         `M M  MMMMM  M M`      MMMM M'        .M 
MM  MMMb. "M MM  MMMMMMMM M  MMMMM  MM M  MMMMM  M MM  MMMMMMMM MM  MMMb. "M 
MM  MMMMM  M MM  MMMMMMMM M  MMMMM  MM M  MMMM' .M MM  MMMMMMMM MM  MMMMM  M 
MM  MMMMM  M MM        .M M  MMMMM  MM M       .MM MM        .M MM  MMMMM  M 
MMMMMMMMMMMM MMMMMMMMMMMM MMMMMMMMMMMM MMMMMMMMMMM MMMMMMMMMMMM MMMMMMMMMMMM 



WELCOME 

To install the AS Chat Reader plugin:
	1. Open Chrome
	2. Navigate to: chrome://extensions
	3. Drag and drop ASChatReader.crx onto the list of extensions.
	
To Use the AS Chat Reader plugin: 
	1. Launch unity game
	2. Navigate your browser to: http://adultswim.com/videos/streams
		NOTE:: It is important to scroll keep the chat box scrolled completely to the bottom to receive new messages
	3. Open the extension by clicking the extension’s symbol in the top right of the browser.
	4. Keep the default URL ws:/localhost:7777
	5. Press open to begin forwarding new messages from the chat to the unity game

.:TROUBLESHOOTING:.

The extension is stuck in a connecting or closing state.

	Restart the unity game and refresh the tab.

The extension is failing to make a connection.
	
	Have adultswim.com/videos/streams as the browsers active tab while trying to use the plugin.
	
	Open port 7777 in your firewall.


Send questions to emanmomot@gmail.com for support.


THANK YOU


